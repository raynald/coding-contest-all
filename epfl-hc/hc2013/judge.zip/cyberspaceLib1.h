/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// function you have to code
int entry_time(int a[], int p[], int N);

