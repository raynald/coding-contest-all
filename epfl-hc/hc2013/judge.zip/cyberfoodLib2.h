/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// function you have to code
long long int estimate_flavours(int S);

// function you may call
long long int eat();
