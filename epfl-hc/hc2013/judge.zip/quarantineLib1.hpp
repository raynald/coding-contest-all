/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// functions you have to code
void load_picture(bool p[1000][1000], int N);
bool query(int r, int c);

