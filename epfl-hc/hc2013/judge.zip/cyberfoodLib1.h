/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// function you have to code
int count_flavours(long long int first);

// function you may call
long long int eat(long long int prev);

