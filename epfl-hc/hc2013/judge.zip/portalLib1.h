/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// useful datastructure
typedef struct{
	int x;
	int y;
} cube;

// function you may call
void answer(int T, int L);

// function you have to code
void speed_assessment(cube c, int N, double s[]);
