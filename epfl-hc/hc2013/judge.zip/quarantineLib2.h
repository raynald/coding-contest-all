/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#define BOOL char
// functions you have to code
void load_picture(BOOL p[1000][1000], int N);
BOOL query(int r1, int c1, int r2, int c2);

