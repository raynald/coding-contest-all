/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#include<vector>
using namespace std;

struct connection {
	int a, b;
};

// function you have to code
pair<vector<int>, vector<int> > draw_literate_painting(int N, int M, const vector<connection> & scheme);
