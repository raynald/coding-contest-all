/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#define BOOL char

// functions you have to code
void load_picture(int N);
BOOL query(int r, int c);
void toggle(int r1, int c1, int r2, int c2);

