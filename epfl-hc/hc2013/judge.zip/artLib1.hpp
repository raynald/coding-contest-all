/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#include<vector>
using namespace std;

// function you have to code
vector<int> draw_charming_painting(int N);
