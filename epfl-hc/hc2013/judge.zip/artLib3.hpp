/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#include<vector>
using namespace std;

struct connection {
  int a, b;
};

// function you have to code
vector<int> arrange_marmots(int N, const vector<connection> & friendships);
