/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// functions you have to code
void load_picture(bool p[1000][1000], int N);
bool query(int r1, int c1, int r2, int c2);

