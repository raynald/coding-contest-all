/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

int* answer(const int teamTour[], int N);

// function you have to code
int* arrange_marmots(int N, int M, int* a, int* b);
