/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

int* answer(const int teamAnswer[], int N);

// function you have to code
int* draw_charming_painting(int N);