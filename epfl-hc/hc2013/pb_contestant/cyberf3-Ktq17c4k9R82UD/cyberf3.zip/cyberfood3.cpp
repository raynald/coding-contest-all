///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include"cyberfoodLib3.hpp"
#include<stdlib.h>
using namespace std;

void happy_meal(){
	for (int i=0; i<100; i++)
		eat(1+rand()%10);
}
