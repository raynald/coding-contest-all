/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

class CyberfoodLib3 {
  public static final int TREES = 10;
  public static final int LEAVES = 100;
  public static final int FORESTS = 10000;

  private static double p[] = new double[TREES];
  private static double t[] = new double[LEAVES];
  private static double s[] = new double[LEAVES];
  private static double m[] = new double[LEAVES];
  private static int index;

  private static java.util.Random r = new java.util.Random();

  private static void create_forest(){
          for (int i=0; i<TREES; i++)
                  p[i] = (1 + r.nextInt(999)) / 1000.0;
          for (int i=0; i<LEAVES; i++)
                  t[i] = (1 + r.nextInt(999)) / 1000.0;
          index = 0;
  }

  private static void oracle(){
          int d=0;
          for (int i=1; i<TREES; i++)
                  d = ( p[i] > p[d] ) ? i : d;
          for (int i=0; i<LEAVES; i++)
                  m[i] += ( t[i] < p[d] ) ? 1:0;
  } 

  static public boolean eat(int id){
          if (index>LEAVES){
                  System.out.printf("No leaves left on the tree\n");
                  System.exit(0);
          }
          s[index] += ( t[index] < p[id-1] ) ? 1:0;
          return t[index++] < p[id-1];
  }

  public static void main(String args[]) {
          for (int f=0; f<FORESTS; f++){
                  create_forest();
                  Cyberfood3.happy_meal();
                  oracle();
          }
          for (int i=0; i<LEAVES; i++){
                  s[i] = s[i]/FORESTS + ((i!=0) ? s[i-1] : 0);
                  m[i] = m[i]/FORESTS + ((i!=0) ? m[i-1] : 0);
          }
          System.err.printf("%.1f%% optimal\n", s[LEAVES-1]/m[LEAVES-1]*100);
          System.out.printf("%s\n",s[LEAVES-1]/m[LEAVES-1] >= 0.9 ? "CORRECT" : "INCORRECT");
  }
}
