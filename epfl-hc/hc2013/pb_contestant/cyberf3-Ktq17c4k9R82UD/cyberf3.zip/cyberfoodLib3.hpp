/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// function you have to code
void happy_meal();

// function you may call
bool eat(int id);
