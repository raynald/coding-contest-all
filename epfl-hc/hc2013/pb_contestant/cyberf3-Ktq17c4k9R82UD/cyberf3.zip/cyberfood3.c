///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include"cyberfoodLib3.h"
#include<stdlib.h>

void happy_meal(){
  int i;
	for (i=0; i<100; i++)
		eat(1+rand()%10);
}
