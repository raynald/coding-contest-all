///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

public class Cyberfood3 {
  private static java.util.Random r = new java.util.Random();

  public static void happy_meal(){
          for (int i=0; i<CyberfoodLib3.LEAVES; i++)
                  CyberfoodLib3.eat(1+r.nextInt(CyberfoodLib3.TREES));
  }
}
