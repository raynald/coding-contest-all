/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// function you have to code
void happy_meal();

// function you may call (0=false, 1=true)
int eat(int id);
