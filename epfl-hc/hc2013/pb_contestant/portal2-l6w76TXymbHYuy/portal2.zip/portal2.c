///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////
#include"portalLib2.h"

void initialize(cube gate, int nobstacles, cube obstacles[]){
}

int check_speed(double speed){
	return 0;
}
