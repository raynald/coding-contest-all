/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

typedef struct{
	int x;
	int y;
} cube;

// functions you have to code
void initialize(cube gate, int nobstacles, cube obstacles[]);
int check_speed(double speed);
