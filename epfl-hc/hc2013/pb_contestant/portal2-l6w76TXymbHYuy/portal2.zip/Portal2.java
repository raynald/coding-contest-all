///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

public class Portal2{
	public static void initialize(Cube gate, int nobstacles, Cube obstacles[]){
	}

	public static int check_speed(double speed){
		return 0;
	}
}
