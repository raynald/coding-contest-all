#include "cryptoLib3.h"

/*
   THIS IS THE ONLY FILE YOU SHOULD SUBMIT
*/

long long int challenge(int plaintext1, int ciphertext1,
                        int plaintext2, int ciphertext2,
                        int plaintext3, int ciphertext3)
{
  const int MAX_WORD = 65536;
  int key1, key2;

  // Standard brute-force attack
  for(key1=0;key1<MAX_WORD;++key1) {
    for(key2=0;key2<MAX_WORD;++key2) {
      if(ciphertext1 != encrypt(plaintext1, key1, key2)) {
        continue;
      }
      if(ciphertext2 != encrypt(plaintext2, key1, key2)) {
        continue;
      }
      if(ciphertext3 != encrypt(plaintext3, key1, key2)) {
        continue;
      }
      return answer(key1, key2);
    }
  }
  // Failure
  return 0;
}
