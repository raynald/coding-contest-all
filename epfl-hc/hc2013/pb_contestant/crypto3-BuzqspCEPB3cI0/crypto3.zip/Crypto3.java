/*
   THIS IS THE ONLY FILE YOU SHOULD SUBMIT
*/

public class Crypto3 {
  public static long challenge(int plaintext1, int ciphertext1,
                               int plaintext2, int ciphertext2,
                               int plaintext3, int ciphertext3)
  {
    final int MAX_WORD = 65536;

    // Standard brute-force attack
    for(int key1=0;key1<MAX_WORD;++key1) {
      for(int key2=0;key2<MAX_WORD;++key2) {
        if(ciphertext1 != CryptoLib3.encrypt(plaintext1, key1, key2)) {
          continue;
        }
        if(ciphertext2 != CryptoLib3.encrypt(plaintext2, key1, key2)) {
          continue;
        }
        if(ciphertext3 != CryptoLib3.encrypt(plaintext3, key1, key2)) {
          continue;
        }
        return CryptoLib3.answer(key1, key2);
      }
    }
    // Failure
    return 0;
  }
}
