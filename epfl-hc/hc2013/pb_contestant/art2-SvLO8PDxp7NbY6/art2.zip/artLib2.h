/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

int* answer(const int teamColors[], const int teamTour[], int N);

// function you have to code
int* draw_literate_painting(int N, int M, int* a, int* b);
