///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

// class Connexion is defined in ArtLib3.java as:
// public class Connexion {
// 	public int a;
// 	public int b;
// 	
// 	Connexion(int a_value, int b_value) {
// 		a = a_value; 
// 		b = b_value; 
// 	}
// }

// If you receive COULD BE CORRECT after compile, it doesn't mean that the solution works
// correctly on the tests, it's because there is no checker supplied with this problem

public class Art3 {
	public static int[] arrange_marmots(int N, Connexion[] friendships) {
		
	}
}