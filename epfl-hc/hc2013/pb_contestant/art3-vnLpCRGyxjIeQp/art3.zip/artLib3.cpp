/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include "artLib3.hpp"

using namespace std;

const int CODE_SIZE_MISMATCH = -1;
const int CODE_FIRST_CREATURE_NOT_HEIDI = -2;
const int CODE_NEGATIVE_MARMOT = -3;
const int CODE_NO_FRIENDSHIP = -4;

static int checkSolution(int n, const vector<connection> & scheme, const vector<int> & teamAnswer) {
	return 0;
}

int main() {
	int numOfCases;
	vector<connection> scheme;
	scanf("%d",&numOfCases);
	for (int tt = 0; tt < numOfCases; tt++) {
		scheme.clear();
		int n,m;
		scanf("%d",&n);
		scanf("%d",&m);
		for (int i = 0; i < m; i++) {
			int a, b;
			scanf("%d %d",&a, &b);
			connection e = {a,b};
			scheme.push_back(e);
		}
		vector<int> teamAnswer = arrange_marmots(n, scheme);
		int checkResult = checkSolution(n, scheme, teamAnswer);
		if (checkResult) {
			printf("INCORRECT - Test case %d: ", tt+1);
			if (checkResult == CODE_SIZE_MISMATCH)
				printf("tour size mismatch, received %d, expected %d", (int) teamAnswer.size(), n+1);
			else if (checkResult == CODE_FIRST_CREATURE_NOT_HEIDI)
				printf("first creature is not Heidi");
			else if (checkResult == CODE_NO_FRIENDSHIP)
				printf("tour includes nonexistent friendship");
			else if (checkResult == CODE_NEGATIVE_MARMOT)
				printf("tour includes negative marmot numbers; not our Cyberspace");
			else if (checkResult > 0)
				printf("creature %d is duplicated or doesn't exist at all", checkResult);
			else
				printf("unknown code error");
			printf("\n");
			exit(0);
		}
	}
	printf("COULD BE CORRECT\n");
	return 0;
}
