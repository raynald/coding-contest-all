///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////
#include <vector>
#include "artLib3.hpp"

using namespace std;

// struct connection describes each pair of friends:
// struct connection {
//  int a, b;
// };

// If you receive COULD BE CORRECT after compile, it doesn't mean that the solution works
// correctly on the tests, it's because there is no checker supplied with this problem

vector<int> arrange_marmots(int N, const vector<connection> & friendships) {
	
}