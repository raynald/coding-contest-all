///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include <stdlib.h>
#include "artLib3.h"

// If you receive COULD BE CORRECT after compile, it doesn't mean that the solution works
// correctly on the tests, it's because there is no checker supplied with this problem

int* arrange_marmots(int N, int M, int* a, int* b) {
	// tour should contain Heidi and marmots: N+1 number
	int* tour = (int*) calloc(N+1, sizeof(int));
	// Insert your code here
	
	
	// Don't modify this code
	int* ret = answer(tour, N);
	free(tour);
	return ret;
}