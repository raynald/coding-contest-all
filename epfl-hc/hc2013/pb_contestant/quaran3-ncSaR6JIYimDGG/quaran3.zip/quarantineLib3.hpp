/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// functions you have to code
void load_picture(int N);
bool query(int r, int c);
void toggle(int r1, int c1, int r2, int c2);

