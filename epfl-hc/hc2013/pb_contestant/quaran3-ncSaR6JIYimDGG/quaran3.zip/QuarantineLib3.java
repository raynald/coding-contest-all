/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

public class QuarantineLib3 {
  private static final int MAXN = 1000;

  public static void main(String args[]){
    java.util.Scanner sc = new java.util.Scanner(System.in);
          int T, Q, r1, c1, r2, c2;
          int N;
          int solTeam, solJudge;
          int cnt;
          String op;
          T = sc.nextInt();
          for (int i=0; i<T; i++){
                  cnt=0;
                  N = sc.nextInt();
                  Quarantine3.load_picture(N);
                  Q = sc.nextInt();
                  for (int j=0; j<Q; j++){
                          op = sc.next();
                          if (op.equals("T")){
                                  r1 = sc.nextInt();
                                  c1 = sc.nextInt();
                                  r2 = sc.nextInt();
                                  c2 = sc.nextInt();
                                  Quarantine3.toggle(r1,c1,r2,c2);
                          }
                          else{
                                  cnt++;
                                  r1 = sc.nextInt();
                                  c1 = sc.nextInt();
                                  solJudge = sc.nextInt();
                                  solTeam = Quarantine3.query(r1,c1)?1:0;
                                  if (solTeam != solJudge){
                                          System.out.printf("INCORRECT - picture %d query %d received %d / expected %d\n",i+1,cnt,solTeam,solJudge);
                                          System.exit(0);
                                  }
                          }
                  }
          }
          System.out.printf("CORRECT\n");
  }
}
