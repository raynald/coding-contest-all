///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include"quarantineLib3.hpp"

void load_picture(int N){
}

bool query(int r, int c){
	return r==c;
}

void toggle(int r1, int c1, int r2, int c2){
}

