///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

public class Quarantine3 {
  public static void load_picture(int N){
  }

  public static boolean query(int r, int c){
          return r==c;
  }

  public static void toggle(int r1, int c1, int r2, int c2){
  }
}
