///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////
#include"portalLib3.hpp"
using namespace std;

void initialize(cube gate, int nobstacles, cube obstacles[]){
}

int check_speed(double speed){
}
