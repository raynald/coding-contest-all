/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

class MayaLib3 {
  static public void take_exit_number(int n) {
        System.out.printf("You told Heidi to take exit number %d\n",n);
  }

  public static void main(String args[]) {
  	Maya3 m3 = new Maya3();
        m3.get_heidi_out();
        System.out.printf("If you want to know whether the above instructions lead Heidi out of the pyramid within a least expected time, submit your code! :)\n");
  }
}
