/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include "mayaLib3.h"

void take_exit_number(int n) {
	printf("You told Heidi to take exit number %d\n",n);
}

int main() {
	get_heidi_out();
	printf("If you want to know whether the above instructions lead Heidi out of the pyramid within a least expected time, submit your code! :)\n");
	return 0;
}
