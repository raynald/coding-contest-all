///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include "takeawayLib1.h"

void find_medalists(int N, int p[], int n[], int t[]) {
	gold_medalist(0);
	silver_medalist(1);
	bronze_medalist(2);
}
