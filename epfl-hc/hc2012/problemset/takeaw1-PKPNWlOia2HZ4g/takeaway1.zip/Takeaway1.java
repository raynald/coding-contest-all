///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

class Takeaway1 {
  void find_medalists(int N, int p[], int n[], int t[]) {
          TakeawayLib1.gold_medalist(0);
          TakeawayLib1.silver_medalist(1);
          TakeawayLib1.bronze_medalist(2);
  }
}
