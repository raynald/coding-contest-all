///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include "giftLib3.hpp"

TAnswer find_heidi() {
        is_heidi_in(2012);
	return TAnswer(1703,2012);
}
