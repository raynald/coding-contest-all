///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

class Gift3 {
  TAnswer find_heidi() {
      GiftLib3.is_heidi_in(2012);
      return new TAnswer(1703, 2012);
  }
}
