///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include "giftLib3.h"

TAnswer find_heidi() {
    is_heidi_in(2012);

    TAnswer ans = {1703, 2012};
    return ans;
}
