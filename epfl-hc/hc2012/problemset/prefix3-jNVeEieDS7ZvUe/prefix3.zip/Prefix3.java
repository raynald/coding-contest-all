
class Prefix3 {
  int minimalNumberToMakeFull(int n, String prefix[]) {
    return 0;
  }
}
