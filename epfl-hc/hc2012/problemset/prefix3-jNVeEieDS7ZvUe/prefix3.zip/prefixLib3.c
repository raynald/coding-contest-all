#include <stdio.h>
#include <stdlib.h>
#include "prefixLib3.h"

const int MAX_LENGTH = 22;

int main(int argc, char** argv){
  FILE* fin = fopen("prefix3.in", "rt");
  FILE* fout = fopen("prefix3.out", "rt");
  int ntc;
  fscanf(fin, "%d\n", &ntc);
  int tc;
  for(tc=0;tc<ntc;++tc) {
    int nlines;
    fscanf(fin, "%d\n", &nlines);
    char** array = (char**) calloc(nlines, sizeof(char*));
    int i;
    for(i=0;i<nlines;++i) {
      array[i] = (char*) calloc(MAX_LENGTH, sizeof(char));
      fscanf(fin, "%21s\n", array[i]);
    }

    int result = minimalNumberToMakeFull(nlines, array);
    int exp;
    fscanf(fout, "%d\n", &exp);
    if ( result != exp) {
      printf("Wrong answer\n");
      return 0;
    }

    for(i=0;i<nlines;++i) {
      free(array[i]);
    }
    free(array);
  }
  printf("Correct");
  return 0;
}
