#include "prefixLib3.h"

int minimalNumberToMakeFull(int n, char* prefix[]) {
  return 0;
}
