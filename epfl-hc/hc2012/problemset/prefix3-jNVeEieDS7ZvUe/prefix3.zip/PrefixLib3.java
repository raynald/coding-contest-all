public class PrefixLib3 {
  public static void main(String args[]){
  try{
    java.util.Scanner sc = new java.util.Scanner(new java.io.File("prefix3.in"));
    java.util.Scanner fout = new java.util.Scanner(new java.io.File("prefix3.out"));
    Prefix3 p3 = new Prefix3();
    int ntc = sc.nextInt();
    int tc;
    for(tc=0;tc<ntc;++tc) {
      int nlines = sc.nextInt();
      String[] array = new String[nlines];
      int i;
      for(i=0;i<nlines;++i) {
        array[i] = sc.next();
      }

      int result = p3.minimalNumberToMakeFull(nlines, array);
      int expected = fout.nextInt();
      if(result != expected) {
        System.out.printf("Wrong answer\n");
        return;
      }
    }
  System.out.printf("Correct\n");
  } catch(Throwable t) {
    System.out.println(t);
  }
  }
}
