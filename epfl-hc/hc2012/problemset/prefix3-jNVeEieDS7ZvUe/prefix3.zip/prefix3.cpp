#include "prefixLib3.hpp"

int minimalNumberToMakeFull(int n, char* prefix[]) {
  return 0;
}
