//////////////////////////
// DO NOT SUBMIT THIS FILE
//////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include "planetLib1.h"

//Some test inputs are contained in file 'planet1.in'

//Each test set looks like this:
//First line: number of cities n
//Second line: startLatitude  walkDistance  planetRadius
//Next n lines: cityLatitude cityLongitude
//Last line: the_right_answer

//Input ends with a set with 0 cities.

int main()
{
    int n;
    int ntests = 0, ncorrect = 0;
    
    FILE* f;
    f = fopen("planet1.in", "r");
    
    while (1 == fscanf(f, "%d", &n) && n != 0)
    {

        double* cityLat = (double*) malloc(n * sizeof(double));
        double* cityLong = (double*) malloc(n * sizeof(double));
        double startLat, walkDistance, planetRadius;

	fscanf(f, "%lf%lf%lf", &startLat, &walkDistance, &planetRadius);
	
	int i;
	for (i = 0; i < n; i++)
	    fscanf(f, "%lf%lf", &cityLat[i], &cityLong[i]);
	int ans, ret;
        fscanf(f, "%d", &ans);
        ntests++;
        if (ans == (ret = countReachable(startLat, walkDistance, planetRadius, n, cityLat, cityLong)))
        {
            ncorrect++;
            printf(".");
        }
        else printf("x");
    }
    printf("\nNumber of tests:           %d\n", ntests);
    printf(  "Number of correct answers: %d\n", ncorrect);
    if (ntests == ncorrect) printf("Congratulations!\n");
    else printf("Wrong answer!\n");

    return 0;
}
