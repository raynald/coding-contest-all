import java.util.Scanner;

//Some test inputs are contained in file 'planet1.in'

//Each test set looks like this:
//First line: number of cities n
//Second line: startLatitude  walkDistance  planetRadius
//Next n lines: cityLatitude cityLongitude
//Last line: the_right_answer

//Input ends with a set with 0 cities.

public class PlanetLib1 {

  private static Planet1 planet1;
  private static Scanner scanner;

  public static void main(String args[]) {
    planet1 = new Planet1();
    try{
	scanner = new Scanner(new java.io.File("planet1.in"));

	int n;
	int ntests = 0, ncorrect = 0;
	while ((n = scanner.nextInt())!= 0)
	{
	    
	    double[] cityLat = new double[n];
	    double[] cityLong = new double[n];
	    double startLat, walkDistance, planetRadius;
	    //scanf("%lf%lf%lf", &startLat, &walkDistance, &planetRadius);
	    startLat = scanner.nextDouble();
	    walkDistance = scanner.nextDouble();
	    planetRadius = scanner.nextDouble();
	    for (int i = 0; i < n; i++)
	    {
		cityLat[i] = scanner.nextDouble();
		cityLong[i] = scanner.nextDouble();
	    }
	    int ans, ret;
	    ans = scanner.nextInt();
	    ntests++;
	    if (ans == (ret = planet1.countReachable(startLat, walkDistance, planetRadius, n, cityLat, cityLong)))
	    {
		ncorrect++;
		System.out.print(".");
	    }
	    else System.out.print("x"); 
	    //else printf("x");
	}
	System.out.print("\nNumber of tests:           " + ntests + "\n");
	System.out.print(  "Number of correct answers: "+ ncorrect + "\n");
	if (ntests == ncorrect) System.out.print("Congratulations!\n");
	else System.out.print("Wrong answer!\n");
    } catch(Throwable t)
	{System.out.println(t);}

  }
}
