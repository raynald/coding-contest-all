// Put here your favorite include files

int countReachable(double startLat, double walkDistance, double planetRadius, int nCities, double cityLat[], double cityLong[])
{
    // return the answer;
}
