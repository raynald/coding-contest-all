public class Planet1 {
    int countReachable(double startLat, double walkDist, double planetRadius, int nCities, double[] cityLat, double[] cityLong)
    {
        return 0;
    }
}
