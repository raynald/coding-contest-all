#ifndef HC2_CRYPTO_LIB_1_H_
#define HC2_CRYPTO_LIB_1_H_

typedef struct Ciphertext_s {
    mpz_t E;
    mpz_t F;
} Ciphertext;

typedef struct PublicKey_s {
    mpz_t p;
    mpz_t g;
    mpz_t y;
} PublicKey;

typedef struct Plaintext_s {
  mpz_t m;
} Plaintext;

/**
 * Decrypts a ciphertext given the public and secret keys it was
 * encrypted under.
 * @param ct The ciphertext to decrypt.
 * @param key The public key.
 * @param x The secret key
 * @return The decrypted ciphertext.
 */
Plaintext decrypt(Ciphertext ct, PublicKey key, mpz_t x);

/**
 * Encrypts a plaintext given a public key and some randomness.
 * @param plaintext The plaintext to encrypt.
 * @param key The public key to encrypt the plaintext with.
 * @param r A random number.
 * @return The encrypted plaintext.
 */
Ciphertext encrypt(Plaintext plaintext, PublicKey key, mpz_t r);

#endif
