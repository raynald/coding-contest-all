import java.math.BigInteger;
// THIS IS THE ONLY FILE YOU WILL SUBMIT

public class Crypto1 {

  /**
   * Decrypts a ciphertext given the public and secret keys it was
   * encrypted under.
   * @param ct The ciphertext to decrypt.
   * @param key The public key.
   * @param x The secret key
   * @return The decrypted ciphertext.
   */
  BigInteger decrypt(Ciphertext ct, PublicKey key, BigInteger x) {
    // THIS IS THE FUNCTION YOU MUST COMPLETE
    return BigInteger.ZERO;
  }

  /**
   * Encrypts a plaintext given a public key and some randomness.
   * @param plaintext The plaintext to encrypt.
   * @param key The public key to encrypt the plaintext with.
   * @param r A random number.
   * @return The encrypted plaintext.
   */
  Ciphertext encrypt(BigInteger plaintext, PublicKey key, BigInteger r) {
    Ciphertext ct = new Ciphertext();
    // E = m * y^r (mod p)
    ct.E = plaintext.multiply(key.y.modPow(r, key.p)).mod(key.p);
    // F = g^(-r)
    ct.F = key.g.modPow(r.negate(), key.p);
    return ct;
  }
}
