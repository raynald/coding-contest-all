#include <gmp.h>

#include "cryptoLib1.h"

Plaintext decrypt(Ciphertext ct, PublicKey key, mpz_t x) {
  Plaintext ret;
  mpz_init(ret.m);

  /* THIS IS THE FUNCTION YOU MUST COMPLETE */

  return ret;
}

Ciphertext encrypt(Plaintext plaintext, PublicKey key, mpz_t r)
{
  Ciphertext ct;
  mpz_init(ct.E);
  
  /* E = m * y^r (mod p) */
  mpz_powm(ct.E, key.y, r, key.p);
  mpz_mul(ct.E, ct.E, plaintext.m);
  mpz_mod(ct.E, ct.E, key.p);

  mpz_init(ct.F);
  /* F = g^(-r) */
  mpz_neg(ct.F, r);
  mpz_powm(ct.F, key.g, ct.F, key.p);
  
  /*  
    Note: if you allocated temporary variables, don't 
    forget to call mpz_clear() on them.
  */
  return ct;
}

