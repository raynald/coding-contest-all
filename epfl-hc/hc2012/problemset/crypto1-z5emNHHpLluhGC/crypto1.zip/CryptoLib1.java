import java.math.BigInteger;
import java.util.Scanner;

public class CryptoLib1 {

  private static Crypto1 crypto1;

  public static void main(String args[]) {
    crypto1 = new Crypto1();
    unitTest();
    System.out.println("OK");
  }

  private static void unitTest() {
    BigInteger p = BigInteger.valueOf(1000003);
    BigInteger g = BigInteger.valueOf(2);
    BigInteger x = BigInteger.valueOf(4242);
    BigInteger r = BigInteger.valueOf(123456);
    BigInteger m = BigInteger.valueOf(654321);
    BigInteger y = g.modPow(x, p);

    PublicKey pk = new PublicKey();
    pk.p = p;
    pk.g = g;
    pk.y = y;

    Ciphertext ct = crypto1.encrypt(m, pk, r);
    if(! ct.E.equals(BigInteger.valueOf(509777))) {
      System.err.println("Encrypt failed (wrong ct.E).");
      System.exit(0);
    }
    if(! ct.F.equals(BigInteger.valueOf(709498))) {
      System.err.println("Encrypt failed (wrong ct.F).");
      System.exit(0);
    }
    BigInteger mp = crypto1.decrypt(ct, pk, x);
    if (! mp.equals(m)) {
      System.err.println("Decrypt failed (m' != m).");
      System.err.println("Expected: " + m);
      System.err.println("Got:      " + mp);
      System.exit(0);
    } else {
      System.out.println("Reciprocal test ok.");
    }
  }

}

class Ciphertext {
  public BigInteger E;
  public BigInteger F;
}

class PublicKey {
  public BigInteger p;
  public BigInteger g;
  public BigInteger y;
}
