#include <gmp.h>

#include "cryptoLib3.hpp"

Plaintext decrypt(Ciphertext ct, PublicKey key, Plaintext m1, Plaintext m2) {

  /* THIS IS THE FUNCTION YOU MUST COMPLETE */

  return m1; /* or return m2 */
}
