import java.math.BigInteger;
// THIS IS THE ONLY FILE YOU WILL SUBMIT

public class Crypto3 {

  /**
   * Guess the decryption of a ciphertext given the public key is was encrypted under
   * and two candidate plaintexts, for "large" public keys.
   * You may assume that the public key and ciphertexts were generated
   * uniformly at random.
   * This function is supposed to be right about 75% of the time.
   * If this function is right less than 71.875% of the time, it will not pass the testcase.
   * @param ct The ciphertext to decrypt.
   * @param key The public key.
   * @param m1 The first candidate plaintext.
   * @param m2 The second candidate plaintext.
   * @return The decrypted ciphertext.
   */
  BigInteger decrypt(Ciphertext ct, PublicKey key, BigInteger m1, BigInteger m2) {
    // THIS IS THE FUNCTION YOU MUST COMPLETE
    return m1; // or return m2;
  }
}
