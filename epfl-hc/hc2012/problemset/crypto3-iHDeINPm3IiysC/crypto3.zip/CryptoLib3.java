import java.math.BigInteger;
import java.util.Scanner;
import java.util.Random;

public class CryptoLib3 {

  private static Crypto3 crypto3;

  public static void main(String args[]) {
    crypto3 = new Crypto3();

    unitTest();
  }

  private static void unitTest() {
    // Note: in the real test, p will change all the time
    BigInteger p = BigInteger.valueOf(1000003);
    Random random = new Random();
    int correct = 0;
    int ntc = 100;
    for(int i=0;i<ntc;++i) {
      // Note: in the real test: g will be distributed uniformly at random
      // in its domain
      BigInteger g = (new BigInteger(19, random)).add(BigInteger.valueOf(2));
      BigInteger x = new BigInteger(19, random);
      BigInteger r = new BigInteger(19, random);
      BigInteger m1 = new BigInteger(19, random);
      BigInteger m2 = new BigInteger(19, random);
      BigInteger y = g.modPow(x, p);

      PublicKey pk = new PublicKey();
      pk.p = p;
      pk.g = g;
      pk.y = y;

      Ciphertext ct = encrypt(m1, pk, r);

      BigInteger m;
      if (Math.random()>0.5) {
        m = crypto3.decrypt(ct, pk, m1, m2);
      } else {
        m = crypto3.decrypt(ct, pk, m2, m1);
      }

      if(m.equals(m1)) {
        correct++;
      } else {
      }
    }
    System.out.println("You were correct " + correct*100./ntc + "% of the time.");
    System.out.println("(You should aim for 75% correct.)");
  }

  static Ciphertext encrypt(BigInteger plaintext, PublicKey key, BigInteger r) {
    Ciphertext ct = new Ciphertext();
    // E = m * y^r (mod p)
    ct.E = plaintext.multiply(key.y.modPow(r, key.p)).mod(key.p);
    // F = g^(-r)
    ct.F = key.g.modPow(r.negate(), key.p);
    return ct;
  }
}

class Ciphertext {
  public BigInteger E;
  public BigInteger F;
}

class PublicKey {
  public BigInteger p;
  public BigInteger g;
  public BigInteger y;
}
