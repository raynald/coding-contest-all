// Put here your favorite include files

int countReachableCountries(int nCities, double cityLat[], double cityLong[])
{
    // return the answer;
}
