public class Planet3
{
    public int countReachableCountries(int nCities, double[] cityLat, double[] cityLong)
    {
	    return 0;
    }
}
