#include "prefixLib1.hpp"

bool isValidPrefixSet(int n, char* prefix[]) {
  return false;
}
