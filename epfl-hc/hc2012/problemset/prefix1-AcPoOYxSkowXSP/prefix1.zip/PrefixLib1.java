public class PrefixLib1 {
  public static void main(String args[]){
  try{
    java.util.Scanner sc = new java.util.Scanner(new java.io.File("prefix1.in"));
    java.util.Scanner fout = new java.util.Scanner(new java.io.File("prefix1.out"));
    Prefix1 p1 = new Prefix1();
    int ntc = sc.nextInt();
    int tc;
    for(tc=0;tc<ntc;++tc) {
      int nlines = sc.nextInt();
      String[] array = new String[nlines];
      int i;
      for(i=0;i<nlines;++i) {
        array[i] = sc.next();
      }

      boolean result = p1.isValidPrefixSet(nlines, array);
      int expected = fout.nextInt();
      if(result != (1==expected)) {
        System.out.printf("Wrong answer\n");
        return;
      }
    }
  System.out.printf("Correct\n");
  } catch(Throwable t) {
    System.out.println(t);
  }
  }
}
