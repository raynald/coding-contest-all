
class Prefix1 {
  boolean isValidPrefixSet(int n, String prefix[]) {
    return false;
  }
}
