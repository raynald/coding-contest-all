#include "prefixLib1.h"

BOOL isValidPrefixSet(int n, char* prefix[]) {
  return FALSE;
}
