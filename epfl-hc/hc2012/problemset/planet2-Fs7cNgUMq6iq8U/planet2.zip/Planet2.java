public class Planet2
{
    public int countBorders(int nCities, double cityLat[], double cityLong[])
    {
        return 0;
    }
}
