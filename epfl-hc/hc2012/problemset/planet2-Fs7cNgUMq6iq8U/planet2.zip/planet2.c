// Put here your favorite include files

int countBorders(int nCities, double cityLat[], double cityLong[])
{
    // return the answer;
}
