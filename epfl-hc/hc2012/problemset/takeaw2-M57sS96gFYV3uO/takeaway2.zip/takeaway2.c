///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include "takeawayLib2.h"

void count_balloons(int N, int p[], int n[], int t[]) {
	min_balloons(0);
	max_balloons(500);
}
