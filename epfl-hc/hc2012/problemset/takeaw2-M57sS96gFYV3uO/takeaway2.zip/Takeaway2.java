///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

class Takeaway2 {
  void count_balloons(int N, int p[], int n[], int t[]) {
          TakeawayLib2.min_balloons(0);
          TakeawayLib2.max_balloons(1);
  }
}
