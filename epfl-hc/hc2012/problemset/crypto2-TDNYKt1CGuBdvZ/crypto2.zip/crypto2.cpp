#include <gmp.h>

#include "cryptoLib2.hpp"

Plaintext decrypt(Ciphertext ct, PublicKey key) {
  Plaintext ret;
  mpz_init(ret.m);

  /* THIS IS THE FUNCTION YOU MUST COMPLETE */

  return ret;
}
