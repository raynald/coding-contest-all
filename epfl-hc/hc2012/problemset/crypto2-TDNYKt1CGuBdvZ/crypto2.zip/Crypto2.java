import java.math.BigInteger;
// THIS IS THE ONLY FILE YOU WILL SUBMIT

public class Crypto2 {

  /**
   * Decrypts a ciphertext given only the public key it was encrypted under,
   * for "small" public keys.
   * @param ct The ciphertext to decrypt.
   * @param key The public key.
   * @return The decrypted ciphertext.
   */
  BigInteger decrypt(Ciphertext ct, PublicKey key) {
    // THIS IS THE FUNCTION YOU MUST COMPLETE
    return BigInteger.ZERO;
  }
}
