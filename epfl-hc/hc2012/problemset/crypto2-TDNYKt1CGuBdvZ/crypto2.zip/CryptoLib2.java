import java.math.BigInteger;
import java.util.Scanner;

public class CryptoLib2 {

  private static Crypto2 crypto2;

  public static void main(String args[]) {
    crypto2 = new Crypto2();

    unitTest();
  }

  private static void unitTest() {
    BigInteger p = BigInteger.valueOf(1000003);
    BigInteger g = BigInteger.valueOf(2);
    BigInteger x = BigInteger.valueOf(4242);
    BigInteger r = BigInteger.valueOf(123456);
    BigInteger m = BigInteger.valueOf(654321);
    BigInteger y = g.modPow(x, p);

    PublicKey pk = new PublicKey();
    pk.p = p;
    pk.g = g;
    pk.y = y;

    Ciphertext ct = new Ciphertext();
    ct.E = BigInteger.valueOf(509777);
    ct.F =BigInteger.valueOf(709498);
    BigInteger mp = crypto2.decrypt(ct, pk);
    if (! mp.equals(m)) {
      System.err.println("Decrypt failed (m' != m).");
      System.err.println("Expected: " + m);
      System.err.println("Got:      " + mp);
      System.exit(0);
    } else {
      System.out.println("OK");
    }
  }
}

class Ciphertext {
  public BigInteger E;
  public BigInteger F;
}

class PublicKey {
  public BigInteger p;
  public BigInteger g;
  public BigInteger y;
}
