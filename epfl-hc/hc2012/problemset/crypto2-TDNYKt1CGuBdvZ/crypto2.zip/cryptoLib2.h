#ifndef HC2_CRYPTO_LIB_2_H_
#define HC2_CRYPTO_LIB_2_H_

typedef struct Ciphertext_s {
    mpz_t E;
    mpz_t F;
} Ciphertext;

typedef struct PublicKey_s {
    mpz_t p;
    mpz_t g;
    mpz_t y;
} PublicKey;

typedef struct Plaintext_s {
  mpz_t m;
} Plaintext;

/**
 * Decrypts a ciphertext given only the public key it was encrypted under,
 * for "small" public keys.
 * @param ct The ciphertext to decrypt.
 * @param key The public key.
 * @return The decrypted ciphertext.
 */
Plaintext decrypt(Ciphertext ct, PublicKey key);

#endif
