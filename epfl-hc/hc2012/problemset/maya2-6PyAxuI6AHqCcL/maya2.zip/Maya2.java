///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

import java.util.Vector;

class Maya2 {
  int fetch_calendar(Vector<Vector<Integer> > p) {
          return 0;
  }
}
