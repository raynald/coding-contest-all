///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include "mayaLib2.h"

// R - number of rooms
// C[r] -- number of corridors in room r
int fetch_calendar(int R, int C[], int p[1024][16]) {
	return 0;
}
