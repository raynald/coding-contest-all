///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

class Gift2 {
  int find_heidi() {
          GiftLib2.is_heidi_in(2012);
          return 2012;
  }
}
