///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include "mayaLib1.hpp"

bool fetch_calendar(vector<vector<int> > p) {
	return true;
}
