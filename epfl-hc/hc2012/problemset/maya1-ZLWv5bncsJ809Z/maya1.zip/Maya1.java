///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

import java.util.Vector;

class Maya1 {
  boolean fetch_calendar(Vector<Vector<Integer> > p) {
          return false;
  }
}
