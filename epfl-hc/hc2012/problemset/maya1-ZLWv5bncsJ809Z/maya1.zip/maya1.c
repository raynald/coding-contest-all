///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include "mayaLib1.h"

// R - number of rooms
// C[r] -- number of corridors in room r
BOOL fetch_calendar(int R, int C[], int p[1024][16]) {
	return FALSE;
}
