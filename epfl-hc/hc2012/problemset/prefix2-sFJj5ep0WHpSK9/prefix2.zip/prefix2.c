#include "prefixLib2.h"

BOOL isFullPrefixSet(int n, char* prefix[]) {
  return FALSE;
}
