#ifndef PREFIX_LIB_2_H_
#define PREFIX_LIB_2_H_

typedef int BOOL;
#define FALSE (0)
#define TRUE (!0)

BOOL isFullPrefixSet(int n, char* prefix[]);

#endif //PREFIX_LIB_2_H_
