#include <cstdio>
#include <cstdlib>
#include "prefixLib2.hpp"

using namespace std;

const int MAX_LENGTH = 22;

int main(int argc, char** argv){
  FILE* fin = fopen("prefix2.in", "rt");
  FILE* fout = fopen("prefix2.out", "rt");
  int ntc;
  fscanf(fin, "%d\n", &ntc);
  int tc;
  for(tc=0;tc<ntc;++tc) {
    int nlines;
    fscanf(fin, "%d\n", &nlines);
    char** array = (char**) calloc(nlines, sizeof(char*));
    int i;
    for(i=0;i<nlines;++i) {
      array[i] = (char*) calloc(MAX_LENGTH, sizeof(char));
      fscanf(fin, "%21s\n", array[i]);
    }

    int result = isFullPrefixSet(nlines, array);
    int exp;
    fscanf(fout, "%d\n", &exp);
    if ( result != exp) {
      printf("Wrong answer\n");
      return 0;
    }

    for(i=0;i<nlines;++i) {
      free(array[i]);
    }
    free(array);
  }
  printf("Correct");
  return 0;
}
