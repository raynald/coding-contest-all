#include "prefixLib2.hpp"

bool isFullPrefixSet(int n, char* prefix[]) {
  return false;
}
