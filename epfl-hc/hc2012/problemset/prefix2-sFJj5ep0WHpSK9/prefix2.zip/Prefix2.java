
class Prefix2 {
  boolean isFullPrefixSet(int n, String prefix[]) {
    return false;
  }
}
