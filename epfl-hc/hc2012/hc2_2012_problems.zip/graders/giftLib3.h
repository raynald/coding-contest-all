/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

typedef int BOOL;
#define FALSE (0)
#define TRUE (!0)

// useful definition
typedef struct TAnswer_s {
	int year1, year2;
} TAnswer;

// function you have to code
TAnswer find_heidi();

// grader function you may call
BOOL is_heidi_in(double year);
