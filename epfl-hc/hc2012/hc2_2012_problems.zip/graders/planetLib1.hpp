#ifndef __PLANET_HPP
#define __PLANET_HPP

int countReachable(double startLat, double walkDistance, double planetRadius, int nCities, double cityLat[], double cityLong[]);

#endif
