/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

typedef int BOOL;
#define TRUE (!0)
#define FALSE 0

// function you have to code
// R - number of rooms
// C[r] -- number of corridors in room r
BOOL fetch_calendar(int R, int C[], int p[1024][16]);
