/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// useful definition
struct TAnswer {
	int year1, year2;
	TAnswer() {};
	TAnswer(int y1, int y2) : year1(y1), year2(y2) {};
};

// function you have to code
TAnswer find_heidi();

// grader function you may call
bool is_heidi_in(double year);
