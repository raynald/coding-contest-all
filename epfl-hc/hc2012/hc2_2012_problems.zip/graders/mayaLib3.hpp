/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// function you have to code
void get_heidi_out();

// grader function you may call
void take_exit_number(int n);
