///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include "dronesLib2.hpp"

void init(int nOuter, int nInner){
}

double minRisk(const Vec2d &router){
  return 0.;
}

