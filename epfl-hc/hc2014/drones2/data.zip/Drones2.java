///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////
import java.util.*;
import java.awt.geom.Point2D;

public class Drones2 {  
  // Function you have to code: Problem initialization. 
  // May be called multiple times. Specifies number of outer and inner polygons
  static void init(int nOuter, int nInner){
    
  }
  
  // Function you have to code: query
  static double minRisk(Point2D router){
    return 0.;
  }
}
