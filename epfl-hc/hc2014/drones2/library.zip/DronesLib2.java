/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////
import java.util.*;
import java.io.*;
import java.awt.geom.Point2D;

public class DronesLib2 {
  /**
   * FUNCTIONS YOU MAY CALL
   *
   * write requested data to passed references, returns false once all
   * the points of a polygon are read
   */
  public static Point2D readOuter(int idx){
	  return uniRead(outer.get(idx));
  }
  
  public static Point2D readInner(int idx){
	  return uniRead(inner.get(idx));
  }
  
  /**
   * Functions you may call to visually debug your solution
   */
  public static void plotLine(Point2D a, Point2D b, int color){
  }

  public static void plotPoint(Point2D a, int color){
  }

  
  private static final int MIC = 0;
  private static final int MAC = 100;
  
  private static Vector<Queue<Point2D> > outer, inner;
  private static Point2D trashV = new Point2D.Double();
  private static double trashD;
  
  private static Point2D uniRead(Queue<Point2D> q){
    if (q.isEmpty()) return null;
    return q.poll();
  }
  
  /**
   * VISUALIZATION
   */
   
  public static void main(String args[]){
    int ntc,no,ni,nq;
	  double x,y,r;
	  Scanner sc = new Scanner(System.in);
	
	  // for each testcase
	  ntc = sc.nextInt();
	  for (int tc=0; tc<ntc; ++tc){
	    // init gnuplot
	
	    // read params
	    no = sc.nextInt();
	    ni = sc.nextInt();
	    nq = sc.nextInt();
	    outer = new Vector<Queue<Point2D> >(no);
	    inner = new Vector<Queue<Point2D> >(ni);
	
	    // read polygons
	    for (int i=0; i<no; ++i){
	      outer.add(new LinkedList<Point2D>());
	      while (true){
		      x = sc.nextDouble(); y = sc.nextDouble();
		      if (x<0) break;
		      outer.get(i).add(new Point2D.Double(x,y));
	      }
	    }
	    for (int i=0; i<ni; ++i){
	      inner.add(new LinkedList<Point2D>());
	      while (true){
		      x = sc.nextDouble(); y = sc.nextDouble();
		      if (x<0) break;
		      inner.get(i).add(new Point2D.Double(x,y));
	      }
	    }
	    
	    // call contestant init
	    Drones2.init(no,ni);
	
	    // query contestant
	    Vector<Double> contestantAnswers = new Vector<Double>();
	    while (nq-- != 0){
		    x = sc.nextDouble(); y = sc.nextDouble();
		    contestantAnswers.add(Drones2.minRisk(new Point2D.Double(x,y)));
	    }
	    
	    // check contestant answers
	    for (int i=0; i<contestantAnswers.size(); ++i){
	      x = sc.nextDouble();
	      if (Math.abs(contestantAnswers.get(i)-x)>0.001){
	        System.out.printf("Wrong: Fails at query %d of test %d with %f " +
	            "instead of %f\n",i,tc,contestantAnswers.get(i),x);
	        return;
	      }
	    }
	  }
	  System.out.printf("Correct - asjdfur923jdsjfg80sd\n");
  }
}
