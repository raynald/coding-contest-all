/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
#include <cmath>
#include "dronesLib2.hpp"
using namespace std;

// Minimal and maximal coordinate
#define MIC 0
#define MAC 100

vector<queue<Vec2d> > outer;
vector<queue<Vec2d> > inner;
Vec2d trashV;
double trashD;

/**
 * DATA INTERFACE
 */

bool uniRead(Vec2d &p, double &x, double &y, queue<Vec2d> &q){
	if (q.empty()) return false;
	p = q.front(); q.pop();
	x = p.x; y = p.y;
	return true;
}

bool readOuter(int idx, Vec2d &p){
	return uniRead(p, trashD, trashD, outer[idx]);
}
bool readOuter(int idx, double &x, double &y){
	return uniRead(trashV, x, y, outer[idx]);
}

bool readInner(int idx, Vec2d &p){
	return uniRead(p, trashD, trashD, inner[idx]);
}
bool readInner(int idx, double &x, double &y){
	return uniRead(trashV, x, y, inner[idx]);
}

/**
 * VISUALIZATION
 */
 

void plotLine(const Vec2d &a, const Vec2d &b, int color){
  
}

void plotPoint(const Vec2d &a, int color){
  
}


int main(){
	int ntc,no,ni,nq;
	double x,y;
	
	// for each testcase
	cin >> ntc;
	for (int tc=0; tc<ntc; ++tc){
	  // init gnuplot
	  
	  // read params
	  cin >> no >> ni >> nq;
	  outer.resize(no);
	  inner.resize(ni);
	
	  // read polygons
	  for (int i=0; i<no; ++i){
	    while (true){
		    cin >> x >> y;
		    if (x<0) break;
		    outer[i].push(Vec2d(x,y));
		    
	    }
	    
	  }
	  for (int i=0; i<ni; ++i){
	    while (true){
		    cin >> x >> y;
		    if (x<0) break;
		    inner[i].push(Vec2d(x,y));
		  }
	  }
	  
	  // call contestant init
	  init(no,ni);
	
	  // query contestant
	  vector<double> contestantAnswers;
	  while (nq--){
		  cin >> x >> y;
		  contestantAnswers.push_back(minRisk(Vec2d(x,y)));
	  }
	  
	  // check contestant answers
	  for (int i=0; i<contestantAnswers.size(); ++i){
	    cin >> x;
	    if (fabs(contestantAnswers[i]-x)>0.001){
	      printf("Wrong: Fails at query %d of test %d with %lf instead of %lf\n",
	          i,tc,contestantAnswers[i],x);
	      return 0;
	    }
	  }
	}
	printf("Correct - asjdfur923jdsjfg80sd\n");
	return 0;
}
