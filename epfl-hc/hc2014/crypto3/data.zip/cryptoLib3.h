/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

void crypto(const char *cipher);
void answer(const char *message);