///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

object Crypto3 {
  def run(cipher: String) : String = {
    "HelloHeidi" //Example usage
  }
}
