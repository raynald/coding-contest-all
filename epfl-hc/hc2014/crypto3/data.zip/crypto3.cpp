///////////////////////////////////////////
// THIS IS THE ONLY FILE YOU WILL SUBMIT //
///////////////////////////////////////////

#include <string>
using namespace std;

#include "cryptoLib3.hpp"

void crypto(string cipher) {
  answer("HelloHeidi");
}
