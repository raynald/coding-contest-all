/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

import java.util.Random;
import java.util.Scanner;

class CryptoLib3 {
  public static void main(String [ ] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println(Crypto3.run(scan.nextLine()));
  }
}
