/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#include <string>

void crypto(std::string cipher);
void answer(std::string message);