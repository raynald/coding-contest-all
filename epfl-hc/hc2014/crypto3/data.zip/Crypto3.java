class Crypto3 {
  public static String run(String cipher) {
    return "HelloHeidi"; //Example usage
  }
}
