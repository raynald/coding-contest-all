/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

object CryptoLib3 {
  def main(args: Array[String]) {
    val answer = readLine()
    println(Crypto3.run(answer))
  }
}
