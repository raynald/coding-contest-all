/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#include "cryptoLib3.h"

#include <stdlib.h>
#include <stdio.h>

char cipher[255];

void answer(const char *message) {
  puts(message);
}

int main() {
  fgets(cipher, 255, stdin);
  crypto(cipher);
}
