//////////////////////
// SUBMIT THIS FILE //
//////////////////////

#include "spyLib3.h"

void scan_marmot(unsigned long long int id){		// runs in Heidi's thread
	// your code goes here
}

void receive_hint(unsigned char info){				// runs in the marmots' thread
	// your code goes here
}

unsigned char is_spy(unsigned long long int id){	// runs in the marmots' thread
	// your code goes here
	return 0;
}

