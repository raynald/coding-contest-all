//////////////////////
// SUBMIT THIS FILE //
//////////////////////

class Spy3 {
	/**
   * Runs in Heidi's process
   * This function is called to indicate that the marmot with the given ID is
   * diligent. It should call SpyLib3.sendHint to communicate this information 
   * to the marmots.
   * It can also read SpyLib3.nScans to find out how many scans there will be 
   * in total
   * (i.e., the value N in the problem statement)
   */
  static void scanMarmot(long id){
    // TODO implement me
  }

  /**
   * Runs in the marmots' process
   * This function is called whenever SpyLib3.sendHint was called. It receives 
   * the information that was passed to sendHint.
   */
  static void receiveHint(byte hint){
    // TODO implement me
  }

  /**
   * Runs in the marmots' thread
   * This function should return whether the marmot with the given ID is a spy,
   * or not. It must decide based on information received through receiveHint.
   */
  static boolean isSpy(long id){
    // TODO implement me
    return false;
  }
};
