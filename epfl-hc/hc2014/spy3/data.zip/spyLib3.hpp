/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

// functions you have to code
void scan_marmot(unsigned long long int id);
void receive_hint(unsigned char info);
unsigned char is_spy(unsigned long long int id);

// functions you may call
unsigned int get_N();
void send_hint(unsigned char info);
