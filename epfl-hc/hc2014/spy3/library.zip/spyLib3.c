/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "spyLib3.h"

#define SCAN 101
#define TEST 110

typedef union _b8 {
    unsigned long long int integer;
    unsigned char byte[8];
} _b8;

typedef union _s9 {
	struct {
		_b8 id;
		unsigned char key;
	} parts;
	unsigned char str[12];
} _s9;

static int pim[2], pih[2];
static unsigned int M, T, remainingHints;
static unsigned int cnt=0, miss=0;
static unsigned long long int list[0x100001];
static unsigned long long int sol[0x100001];
static char testcase;

static unsigned long long int x_n = 42958ull;
static long long int rand_24(void) {
    const unsigned long long int A = 123ull;
    const unsigned long long int C = 45678ull;
    x_n = A*x_n + C;
    return (x_n & 0xFFFFFF);
}
static unsigned long long int rand_63(void) {
    const unsigned long long int A = 123ull;
    const unsigned long long int C = 45678ull;
    x_n = A*x_n + C;
    return (x_n>>1);
}

static int comp(const void *a, const void *b){
	if ( *(unsigned long long int*)a < *(unsigned long long int*)b ) return -1;
	if ( *(unsigned long long int*)a == *(unsigned long long int*)b ) return 0;
	else return 1;
}

unsigned int get_N(){
	return M;
}

void send_hint(unsigned char info){
	if (!remainingHints){
		close(pih[0]);
		close(pim[1]);
		printf("Heidi sent too many hints\n");
		exit(0);
	}
	_s9 buf;
	buf.parts.key = SCAN;
	buf.parts.id.byte[0] = info;
	write( pim[1], buf.str, sizeof(buf.str) );
	remainingHints = remainingHints - 1;
}

static unsigned char test_marmot(unsigned long long int id, unsigned char sol){
	_s9 buf;
	buf.parts.key = TEST;
	buf.parts.id.integer = id;
	write( pim[1], buf.str, sizeof(buf.str) );
    read( pih[0], buf.str, sizeof(buf.str) );
    if (sol){
    	cnt++;
    	if (!buf.parts.key) miss++;
    }
    else if (buf.parts.key) return 0;
    return 1;
}

static void marmots(){
	_s9 buf;
    while ( read( pim[0], buf.str, sizeof(buf.str) ) > 0 ){
    	if ( buf.parts.key == SCAN )
    		receive_hint( buf.parts.id.byte[0] );
    	if ( buf.parts.key == TEST ){
    		buf.parts.key = is_spy( buf.parts.id.integer ) ? 1 : 0;
    		write( pih[1], buf.str, sizeof(buf.str) );
    	}
    }
}

static void heidi(){
	unsigned int i;
	unsigned long long int id;
	remainingHints = M*2;
	for (i=0; i<M; i++){
		list[i] = rand_63();
		scan_marmot( list[i] );
		sol[i] = list[i];
	}
	qsort( sol, M, sizeof(unsigned long long int), comp );
	for (i=0; i<T; i++){
		id = rand()%2 ? rand_63() : list[ rand_24() % M];			
		if ( !test_marmot( id, bsearch( &id, sol, M, sizeof(unsigned long long), comp ) == NULL ) ) {
			close(pih[0]);
			close(pim[1]);
			printf("Fellow marmot has been identified incorrectly as spy\n");
			exit(0);
		}	
	}
	if ( (100.0*miss)/cnt > 0.1 ){
		close(pih[0]);
		close(pim[1]);
		printf("You missed %.3f %% of the spies (%d out of %d)\n", (100.0*miss)/cnt, miss, cnt);
		exit(0);
	}
	close(pih[0]);
	close(pim[1]);
	printf("CORRECT_efc2104fd198eed461b3b67a336ca4a4\n");
}	

int main(int argc, char* argv[]){
	scanf("%hhu %u %u",&testcase,&M,&T);
	srand(15032063%(1<<(2*testcase)));	
	
	pipe(pim);
	pipe(pih);
   	int childpid = fork();
          
 	if(childpid == 0){
 		close(pih[0]);
		close(pim[1]);
		marmots();
	}
	else{
        close(pih[1]);
        close(pim[0]);
        heidi();
	}
	return 0;
}
