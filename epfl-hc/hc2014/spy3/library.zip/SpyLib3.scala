import scala.sys.process.Process
import scala.sys.process.ProcessIO
import scala.concurrent.SyncVar
import java.io.File

object SpyLib3 {

  /** Call this method from your Heidi code, to send a hint to the marmots.
   *  It causes the Marmot's receiveHint method to be called. */
  def sendHint(hint: Byte): Unit = {
    if (_remainingHints <= 0) {
      println("Incorrect -- Heidi used too many hints")
      sys.exit(0)
    }
    
    _marmotProcess.write(HintMessage(hint))
    _remainingHints -= 1
  }
  
  /** Call this methods to receive the total number of scans
   *  (i.e., the value N from the problem statement) 
   */
  def nScans: Int = _nScans
  
  // Implementation details follow...
  
  // The messages that marmots and Heidi exchange
  sealed abstract class Message
  case class TestMessage(id: Long) extends Message
  case class AnswerMessage(result: Boolean) extends Message
  case class HintMessage(hint: Byte) extends Message
  
  /** This class runs the marmot behavior, and calls the isSpy and receiveHint methods. */
  class Marmot {
    System.err.println("Marmot thread started...")

    // Creating input/output streams. Note that order is important (output first)
    // because input stream creation blocks until some header data is sent.
    val out = new java.io.ObjectOutputStream(System.out)
    val in = new java.io.ObjectInputStream(System.in)

    def run(): Unit = {
      while (true) {
        try {
          in.readObject() match {
            case TestMessage(id) =>
              System.err.print("Marmot received query for " + id)
              val answer = Spy3.isSpy(id)
              System.err.println(", answering " + answer)
              out.writeObject(AnswerMessage(answer))
            case HintMessage(info) => 
              System.err.println("Marmot received hint " + info)
              Spy3.receiveHint(info)
            case _ =>
              assert(false, "Heidi must not send gibberish")
          }
        } catch {
          case _: java.io.EOFException =>
            System.err.println("Marmot exiting.")
            sys.exit(0)
        }
      }
    }
    run()
  }

  /** This class runs Heidi, and calls the scanMarmot method. */
  class Heidi {
    System.err.println("Heidi thread started...")

    def testMarmot(id: Long): Boolean = {
      System.err.println("Heidi testing Marmot " + id)
      _marmotProcess.write(TestMessage(id))
      _marmotProcess.read() match {
        case AnswerMessage(result) => result
        case _ =>
          assert(false, "Marmot must not send gibberish")
          false  // Makes compilers happy
      }
    }
    
    def run(): Unit = {
      val s = new java.util.Scanner(System.in)
      _nScans = s.nextInt()
      val nTests = s.nextInt()
      _remainingHints = 2 * nScans
      var nSpiesTested = 0
      var nSpiesMissed = 0
      
      for (i <- 0 until (_nScans + nTests)) {
        val op = s.nextInt()
        val id = s.nextLong()
        val solution = s.nextInt() != 0
        
        op match {
          case 0 => 
            val answer = testMarmot(id)
            if (solution) {
              nSpiesTested += 1
              if (!answer) nSpiesMissed += 1
            } else {
              if (answer) {
                println("Incorrect -- Loyal marmot fellow was identified as spy")
                sys.exit(0)
              }
            }
          case 1 =>
            System.err.println("Heidi scanning Marmot " + id)
            Spy3.scanMarmot(id)
        }
      }

      if (100.0 * nSpiesMissed / nSpiesTested > 0.1) {
        println("Incorrect -- You missed %.3f%% of the spies (%d out of %d)".format(
          100.0 * nSpiesMissed / nSpiesTested,
          nSpiesMissed, nSpiesTested))
        sys.exit(0)
      }
      
      println("CORRECT_efc2104fd198eed461b3b67a336ca4a4")
      _marmotProcess.terminate()
    }
    run()
  }

  /** This class encapsulates the marmot thread, running in its own process. */
  class MarmotProcess() {
    // The process's standard input. Write here to send data to the process
    var stdin: java.io.ObjectOutputStream = null
    // The process's standard output. Read from here to get data from the process
    var stdout: java.io.ObjectInputStream = null
    
    private def start(): Unit = {
      System.err.println("About to launch a new marmot")
      val pb = new java.lang.ProcessBuilder("/usr/local/bin/scala", "-J-Xrs", "-J-Xss8m", "-J-Xmx393216k", "SpyLib3", "marmot")
      pb.redirectError(java.lang.ProcessBuilder.Redirect.INHERIT)
      val p = pb.start()
      
      stdin = new java.io.ObjectOutputStream(p.getOutputStream())
      stdout = new java.io.ObjectInputStream(p.getInputStream())
      
      System.err.println("Marmot launched.")
    }
    
    start()
    
    def write(o: Any): Unit = {
      stdin.writeObject(o)
      stdin.flush()
    }
    
    def read(): Any = {
      stdout.readObject()
    }
    
    def terminate(): Unit = {
      stdin.close()
    }
  }

  private var _marmotProcess: MarmotProcess = null
  private var _remainingHints: Int = -1
  private var _nScans: Int = -1
  
  def main(args: Array[String]): Unit = {
    if (args.size > 0 && args(0) == "marmot") {
      new Marmot()
    } else {
      _marmotProcess = new MarmotProcess
      new Heidi()
    }
  }
}
