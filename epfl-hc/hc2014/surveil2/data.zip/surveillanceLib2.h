#define MAX_N 1000
#define MAX_FRIENDS 100

void nodes_to_monitor(int to_monitor[], int* size_to_monitor, int network[][MAX_N],
                      int nb_nodes, int friend_set[], int friend_set_size);
