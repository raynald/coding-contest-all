//////////////////////
// SUBMIT THIS FILE //
//////////////////////
#include <stdio.h>
#include <string.h>

#include "surveillanceLib2.h"

/*
 *
 * INPUT:
 * -> network
 *  This is the graph (or network) represented as adjacency list. First index
 *  to this array is node number, and is in the interval 0..nbNodes-1. If first
 *  index is 'i', then second index is used to access all the neighbours of node
 *  'i'. You can iterate through all the neighbors until you find the value -1,
 *  which denotes the end of the neighbours list. Do not be confused by the
 *  fact that network has actually allocated MAXN entries for neighbours of
 *  every node.
 *
 *  -> nb_nodes
 *  Number of nodes in the received network.
 *
 *  -> friend_set
 *  array of terminals of all the friends (including Heidi)
 *  
 *  -> friend_set_size
 * Number of terminals in friend_set
 *
 *  OUTPUT:
 * -> to_monitor
 *  array of nodes to monitor. Array is already allocated with MAX_N size and you don't
 *  have to worry about that.
 *
 *  -> size_to_monitor
 *  size of the array to_monitor. This is a pointer to only one integer, and not
 *  the array.
 *
 */

void nodes_to_monitor(int to_monitor[], int* size_to_monitor, int network[][MAX_N],
                      int nb_nodes, int friend_set[], int friend_set_size) {
	// your code goes here
}

