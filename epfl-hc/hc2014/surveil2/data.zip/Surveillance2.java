public class Surveillance2 {
  public static int[] nodesToMonitor(Node[] adjacencyList, int[] friends) {
    // your code goes here
  }
}
