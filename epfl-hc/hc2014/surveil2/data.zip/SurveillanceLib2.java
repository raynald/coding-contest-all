import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

class Node {
  Node(int[] neighbors) { this.neighbors = neighbors; }
  final public int[] neighbors;
}

public class SurveillanceLib2 {
  public static void main(String[] args) throws IOException {
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

    int T = Integer.parseInt(in.readLine());
    while (T-- > 0) {
      int N = Integer.parseInt(in.readLine());
      adjacencyList = new Node[N];
      for (int i = 0; i < N; ++i) {
        String[] token = in.readLine().split(" ");
        int c = Integer.parseInt(token[0]);
        assert c == token.length - 1;
        int[] neighbors = new int[c];
        for (int j = 1; j <= c; ++j) {
          neighbors[j-1] = Integer.parseInt(token[j]);
        }
        adjacencyList[i] = new Node(neighbors);
      }
      int F = Integer.parseInt(in.readLine());
      String[] token = in.readLine().split(" ");
      assert F == token.length;
      int[] friends = new int[F];
      for (int i = 0; i < F; ++i) {
        friends[i] = Integer.parseInt(token[i]);
      }
      int[] solution = Surveillance2.nodesToMonitor(adjacencyList, friends);
      if (isCut(solution, friends)) {
        System.out.println(solution.length);
      } else {
        System.out.println(-1);
      }
    }
  }
  
  private static boolean isCut(int[] solution, int[] friends) {
    vis = new int[adjacencyList.length];
    Arrays.sort(friends);
    for (int i = 0; i < solution.length; ++i) {
      vis[solution[i]] = -1;
      if (Arrays.binarySearch(friends, solution[i]) >= 0) return false;
    }
    for (int i = 0; i < friends.length; ++i)  if (dfs(friends[i], i+1)) return false;
    return true;
  }
  
  private static boolean dfs(int src, int clr) {
    if (vis[src] != 0) return vis[src] != -1 && vis[src] != clr;
    vis[src] = clr;
    for (int i = 0; i < adjacencyList[src].neighbors.length; ++i) {
      if (dfs(adjacencyList[src].neighbors[i], clr)) return true;
    }
    return false;
  }
  
  private static Node[] adjacencyList;
  private static int[] vis;
}
