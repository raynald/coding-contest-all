/////////////////////////////
// DO NOT SUBMIT THIS FILE //
/////////////////////////////
#include <vector>

// functions you have to code
std::vector<int> nodes_to_monitor(const std::vector<std::vector<int> > &adjacency_list, const std::vector<int> &friend_set);
