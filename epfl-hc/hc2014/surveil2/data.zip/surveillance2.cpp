//////////////////////
// SUBMIT THIS FILE //
//////////////////////

#include "surveillanceLib2.hpp"

#include <vector>

std::vector<int> nodes_to_monitor(const std::vector<std::vector<int> > &adjacency_list, const std::vector<int> &friend_set) {
// your code goes here
}
