#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "surveillanceLib2.h"

// the adjacency list
// first index goes to nbNodes
// secondindex goes until the value -1
int _network[MAX_N][MAX_N];
// visited during dfs
int _vis[MAX_N];
// friends passed to contestant's function
// there is friends_cnt of them
int _friends[MAX_FRIENDS];
// hash-like 0/1 entry of friends
int _friends_set[MAX_N];
// here goes contestant's solution. They also filll in solution_size
int _solution[MAX_N];

int _dfs(int node, int clr) {
    if (_vis[node] != -1) {
        return _vis[node] != -2 && _vis[node] != clr;
    }
    _vis[node] = clr;
    int i;
    for (i = 0; _network[node][i] != -1; i++) {
        if (_dfs(_network[node][i], clr)) {
            return 1;
        }
    }
    return 0;
}

int main() {
    int nbNodes, testCases, t, i, neighbors, nbr, node;
    int friends_cnt, f;
    int solution_size;
    int to_print;

    scanf("%d", &testCases);

    for (t = 0; t < testCases; t++) {
        scanf("%d", &nbNodes);

        for (i = 0; i < nbNodes; ++i) {
            scanf("%d", &neighbors);

            nbr = 0;
            for (; nbr < neighbors; nbr++) {
                scanf("%d", &node);
                _network[i][nbr] = node;
            }
            // THIS IS HOW WE KNOW WHEN THE NEIGHBORS LIST IS OVER
            _network[i][nbr] = -1;
        }

        scanf("%d", &friends_cnt);
        for (f = 0; f < friends_cnt; ++f) {
            scanf("%d", &node);
            _friends[f] = node;
        }

        solution_size = 0;
        nodes_to_monitor(_solution, &solution_size, _network, nbNodes,
                        _friends, friends_cnt);

        to_print = solution_size;

        memset(_vis, -1, sizeof(_vis));
        memset(_friends_set, 0, sizeof(_friends_set));

        // creating friends set
        for (f = 0; f < friends_cnt; f++) {
            _friends_set[_friends[f]] = 1;
        }

        for (f = 0; f < solution_size; f++) {
            // solution should not contain any terminal nodes (friends)
            if (_friends_set[_solution[f]]) {
                to_print = -1;
            }
            _vis[_solution[f]] = -2;
        }

        for (f = 0; to_print >= 0 && f < friends_cnt; ++f) {
            // dfs from every friend to check if other friends could be reached
            if (_dfs(_friends[f], f)) {
                to_print = -1;
            }
        }

        // output is later compared to the expected_output_file
        // so minimality constraint is checked there, but validity of 
        // solution is checked here dynamically (with dfs)
        printf("%d\n", to_print);
    }

    return 0;
}
